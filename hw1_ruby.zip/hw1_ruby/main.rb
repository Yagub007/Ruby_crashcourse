require_relative 'student'


student1 = Student.new('Aliev', 'Yagub', Date.new(2006, 9, 19))
student2 = Student.new('Agalarov', 'Ali', Date.new(2004, 5, 17))
student3 = Student.new('Agalarov', 'Elvin', Date.new(2007, 1, 18))
student4 = Student.new('Vorokuta', 'Artem', Date.new(2004, 7, 26))

student1.add_student(student1)
student1.add_student(student2)
student1.add_student(student3)
student1.add_student(student4)

puts "Додані студенти:"
puts Student.students

puts "\nКількість років кожного з студентів:"
Student.students.each do |student|
  puts "#{student.name} #{student.surname} - #{student.calculate_age}."
end

test_age = 20
puts "\nСтуденти яким #{test_age}:"
puts Student.get_students_by_age(test_age)

test_name = 'Yagub'
puts "\nСтуденти з ім'ям #{test_name}:"
puts Student.get_students_by_name(test_name)

puts "\nВидалення Ворокути Артема..."
student1.remove_student(student4)

puts "\nСписок після видалення:"
puts Student.students
