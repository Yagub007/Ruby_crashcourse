require 'date'

class Student
  attr_accessor :surname, :name, :date_of_birth

  @@students = []

  def initialize(surname, name, date_of_birth)
    @surname = surname
    @name = name
    @date_of_birth = date_of_birth

    raise ArgumentError, "Дата народження повинна бути в минулому" if date_of_birth >= Date.today
    add_student(self)
  end

  def calculate_age
    now = Date.today
    age = now.year - @date_of_birth.year
    age -= 1 if (now.month < @date_of_birth.month) || (now.month == @date_of_birth.month && now.day < @date_of_birth.day)
    age
  end

  def add_student(student)
    not_unique_student = false
    @@students.each do |x|
      if x.surname == student.surname && x.name == student.name && x.date_of_birth == student.date_of_birth
        not_unique_student = true
        break
      end
    end
    @@students << student unless not_unique_student
  end

  def remove_student(student)
    @@students.delete_if { |x| x.surname == student.surname && x.name == student.name && x.date_of_birth == student.date_of_birth }
  end

  def self.get_students_by_age(age)
    @@students.select { |x| x.calculate_age == age }
  end

  def self.get_students_by_name(name)
    @@students.select { |x| x.name == name }
  end

  def to_s
    "#{@name} #{@surname}, Дата народження: #{@date_of_birth.strftime('%Y-%m-%d')}"
  end
  def self.students
    @@students
  end

end

